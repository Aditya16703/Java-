package compexample;

import java.util.Comparator;

public class PeopleComparator implements Comparator{
    private String sortOrder;
    private int sortColumn;
    	public PeopleComparator(int sortColumn, String sortOrder){
	    //Your Job (*hint* you probabaly want to store the two arguments)
	    //The first argument takes a column that matches up with the
	    //constants Person.COL_LASTNAME, Person.COL_FIRSTNAME, 
	    //Person.COL_PHONE, Person.COL_EMAIL, and Person.COL_COLOR
	    //The second matches ComparatorExample.ASCENDING and 
	    //ComparatorExample.DESCENDING (two string constants).
	}
	public int compare(Object o1,Object o2){
	    //Your Job (you must cast o1 and o2 to Person, but
	    //make sure to check that they are indeed instanceof Person)
	    //This MUST follow the Comparator interface.
	    //To compare the colors, try using getColor() in
	    //class Person. To compare the other fields, note
	    //that many things are already comparable, using
	    //someObj1.compareTo(someObj2)
   
	}

}
