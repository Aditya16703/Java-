package lab2;

public class MadLib extends MadLibTemplate {

  // this is where most of your code is going to go
  
}


// but you can also declare your helper classes out here (or in their
// own files in the lab2 package).

